__version__ = "0.3.0"
__authors__ = ["Anthony Lomax",  "Sonja Gaviano", "Matteo Bagagli"]
__maintainers__ = ["Matteo Bagagli", "Anthony Lomax",  "Sonja Gaviano"]
__date__ = "06.2023"
